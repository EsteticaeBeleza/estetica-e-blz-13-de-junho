<!DOCTYPE html>
<html lang="pt-br">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/estiloprincipal.css">
	<link rel="icon" type="image/x-icon" href="/imagens/favicon.png">
	
        <title>Estética & Beleza - Tela Inicial</title>

</head>

<div class="topnav">
<?php
	//Coloca o menu que está no arquivo
	include 'menu.php';
?>
</div>



<div class="sidenav">
  <a href="principal.php">Página Inicial</a>
  <a href="">Cabelos</a>
  <a href="">Unhas</a>
  <a href="">Maquiagem</a>
  <a href="">Sobrancelhas</a>
  <a href="">Nossos Produtos</a>
</div>

</body>
</html>


