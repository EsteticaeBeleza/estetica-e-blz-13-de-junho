<?php

//Faz a conexão com o BD.
require 'conexao.php';

?>